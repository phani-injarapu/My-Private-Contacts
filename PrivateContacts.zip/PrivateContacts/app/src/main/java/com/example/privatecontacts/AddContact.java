package com.example.privatecontacts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddContact extends AppCompatActivity {
    EditText name, phone, mail;
    Button add;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);

        name = findViewById(R.id.name);
        phone = findViewById(R.id.phone);
        mail = findViewById(R.id.mail);
        DB = new DBHelper(this);

        add = findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();
                String phoneTXT = phone.getText().toString();
                String emailTXT = mail.getText().toString();

                if(nameTXT.equals("")||phoneTXT.equals("")||emailTXT.equals(""))
                    Toast.makeText(AddContact.this, "Please Enter All Fields", Toast.LENGTH_SHORT).show();
                else
                { Boolean checkphone = DB.checkPhone(phoneTXT);
                    if(checkphone==false)
                    {
                        Boolean insert = DB.insertContactDetails(nameTXT, phoneTXT, emailTXT);
                        if(insert==true){
                            Toast.makeText(AddContact.this, "Saved !", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(),ContactActivity.class);
                            startActivity(intent);
                        }else{
                            Toast.makeText(AddContact.this, "Failed, Please Try again !!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(AddContact.this, "Contact Already Exists", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), ContactActivity.class);
                        startActivity(intent);
                    }
                }
            }
        });

    }
}