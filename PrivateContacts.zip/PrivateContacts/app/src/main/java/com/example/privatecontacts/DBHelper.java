package com.example.privatecontacts;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "Userdata.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table Userdetails(email TEXT primary key, password TEXT, secret TEXT)");
        DB.execSQL("create Table UserContactdetails(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT, phone TEXT, mail TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int ii) {
        DB.execSQL("drop Table if exists Userdetails");
        DB.execSQL("drop Table if exists UserContactdetails");
        onCreate(DB);
    }

    public Boolean insertContactDetails(String name, String phone, String mail) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name",name);
        contentValues.put("phone",phone);
        contentValues.put("mail",mail);
        long result = DB.insert("UserContactdetails",null,contentValues);
        if(result == -1)
        {
            return false;
        }else
        {
            return true;
        }
    }

    public Boolean insertUserDetails(String email, String password, String secret) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email",email);
        contentValues.put("password",password);
        contentValues.put("secret",secret);
        long result = DB.insert("Userdetails",null,contentValues);
        if(result == -1)
        {
            return false;
        }else
        {
            return true;
        }
    }

    public Boolean checkEmailid(String email) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from Userdetails where email = ?", new String[]{email});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public Boolean checkLogin(String email, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from Userdetails where email = ? and password = ?", new String[]{email,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }

    public Boolean checkPhone(String phone) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from UserContactdetails where phone = ?", new String[]{phone});
        if (cursor.getCount()>0)
            return true;
        else
            return false;
    }


    public Cursor getdata()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from UserContactdetails",null);
        return cursor;
    }
}
